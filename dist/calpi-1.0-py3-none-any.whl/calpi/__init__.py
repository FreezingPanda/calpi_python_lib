# mylibrary/__init__.py

from .calpi import calpiinfo
# mylibrary/__init__.py

