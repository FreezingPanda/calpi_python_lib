# mylibrary/__init__.py

from .calpi import calpi
# mylibrary/__init__.py

